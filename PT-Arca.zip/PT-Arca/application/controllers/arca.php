<?php 
	
	class arca extends CI_Controller{

		public function index(){
			$this->load->view('a_index');
		}

		public function proses_tambah(){
			if(isset($_POST['save'])){
				$data = array('id' =>$this->input->post('id') ,
								'nama'=>$this->input->post('nama'),
								'pembayaran'=>$this->input->post('pembayaran'),
								'gaji1'=>$this->input->post('gaji1'),
								'gaji2'=>$this->input->post('gaji2'),
								'gaji3'=>$this->input->post('gaji3'),
								
								);

				$x1 = explode("%", $data['gaji1']);
				$x2 = explode("%", $data['gaji2']);
				$x3 = explode("%", $data['gaji3']);
				if ($jumlah=$x1[0]+$x2[0]+$x3[0]==100) {
					echo "Berhasil";

					$this->db->select('*');
					$this->db->from('buruh');
					$this->db->where('id',$this->input->post('id'));
					$result=$this->db->get();
					
						if($result->num_rows()<>0){
							echo "ID Sudah  ada";
							
						}else if($hasil=$this->db->insert('buruh',$data)){
							echo "Berhasil";
							redirect('arca/tampil');

							
						}else{
							echo"Gagal";
							mysqli_error();
							exit();
						}
				}else{
					echo "Salah";
				}
				

				
			}
		}
	

		public function tampil(){
			$this->db->select('*');
			$this->db->from('buruh');
			$result=$this->db->get();
			$sql=$result->result_array();
			$data['data']=$sql;
			$this->load->view('a_tampil',$data);
		}

		public function edit($id){
			$this->db->select('*');
			$this->db->from('buruh');
			$this->db->where('id', $id);
			$result=$this->db->get();
			$sql=$result->result_array();
			$data['data']=$sql;
			$this->load->view('a_edit',$data);
		}

		public function proses_ubah(){
			if(isset($_POST['ubah'])){
				$data = array(
								'nama'=>$this->input->post('nama'),
								'pembayaran'=>$this->input->post('pembayaran'),
								'gaji1'=>$this->input->post('gaji1'),
								'gaji2'=>$this->input->post('gaji2'),
								'gaji3'=>$this->input->post('gaji3')
								);
				$this->db->where('id',$this->input->post('id'));
				$hasil=$this->db->update('buruh',$data);
				if($hasil){
				redirect('arca/tampil');
				}else{
					echo "Pengeditan Gagal";
				}
			}
		}

		public function delete($id){
			$data['id']=$id;
			$hasil=$this->db->delete('buruh',$data);
			if($hasil){
				echo "Berhasil";
				redirect('arca/tampil');
			}else{
				echo "Penghapusan Gagal";
			}
		}

		

	}
?>