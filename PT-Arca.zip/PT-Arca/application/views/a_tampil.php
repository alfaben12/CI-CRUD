<!DOCTYPE html>
<html>
	<head>
		<title>List</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>inc/css/bootstrap.css">
	</head>
	<body>
	<h1 align="center">Arca Coding Challenge</h1>
		<div class="table-responsive">          
			<table class="table">
			  <?php 
								foreach ($data as $row) {
									# code...
									?>
			    <thead>
			      <tr>
			        <th>ID</th>
			        <th>Nama</th>
			        <th>Pembayaran</th>
			        <th>Buruh A</th>
			        <th>Buruh B</th>
			        <th>Buruh C</th>
			        <th>Tanggal</th>
			        <th>Aksi</th>
			      </tr>
			    </thead>
			    <tbody>
			      <tr>
			        <td><?= $row['id'] ?></td>
			        <td><?= $row['nama'] ?></td>
			        <td><?= $row['pembayaran'] ?></td>
			        <td><?= $row['gaji1'] ?></td>
			        <td><?= $row['gaji2'] ?></td>
			        <td><?= $row['gaji3'] ?></td>
			        <td><?= $row['tanggal'] ?></td>
			        <td>
			        	<a href="<?php echo base_url()?>index.php/arca/edit/<?= $row['id'] ?>"><button class="btn btn-primary"><span class="glyphicon glyphicon-cog"></span></button></a>

						<a href="<?php echo base_url()?>index.php/arca/delete/<?= $row['id'] ?>"><button class="btn btn-primary"><span class="glyphicon glyphicon-trash"></span></button></a>
					</td>
			      </tr>
			      <?php
			  }
			 ?>
			    </tbody>
			</table>
 		</div>
 		<a href="<?php echo base_url()?>index.php/arca/">Back</a>
	</body>
</html>