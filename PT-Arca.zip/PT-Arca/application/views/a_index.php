<!DOCTYPE html>
<html>
	<head>
		<title>Buruh</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>inc/css/bootstrap.css">
	</head>
	<body>
	<h1 align="center">Arca Coding Challenge</h1>
				<?php echo form_open('arca/proses_tambah') ?>
			<div class="container">
				<div class="form-group">
			      <label for="usr">ID : </label>
			      <input type="text" class="form-control" id="usr" placeholder="ID" name="id" required="">
			    </div>
				<div class="form-group">
			      <label for="usr">Nama : </label>
			      <input type="text" class="form-control" id="usr" placeholder="Nama" name="nama" required="">
			    </div>
				    <?php echo form_open('arca/proses_persentase') ?>
					<div class="form-group">
				      <label for="usr">Pembayaran : </label>
				      <input type="text" class="form-control" id="usr" placeholder="Pembayaran" name="pembayaran" >
				    </div>
				    <div class="form-group">
				      <label for="usr">Buruh A : </label>
				      <input type="text" class="form-control" id="usr" placeholder="Buruh A" name="gaji1" >
				    </div>
				    <div class="form-group">
				      <label for="usr">Buruh B : </label>
				      <input type="text" class="form-control" id="usr" placeholder="Buruh B" name="gaji2" >
				    </div>
				    <div class="form-group">
				      <label for="usr">Buruh C : </label>
				      <input type="text" class="form-control" id="usr" placeholder="Buruh C" name="gaji3" >
				    </div>
				    <?php echo form_close() ?>
			    <td> 
					<button name="save" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-save"></span></button>
				</td>
			<?php echo form_close() ?>
			
		</div>
	</body>
</html>